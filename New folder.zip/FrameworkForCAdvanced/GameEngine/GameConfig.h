#pragma once
// Configuration of the game
// and built library
//

namespace gamerize
{

	/**
	* The configuration of the game
	* 
	**/
	class GameConfig
	{
	public:

	private:
	};
};

