#include "PlayState.h"
#include "ResourceManager.h"
#include "Define.h"

PlayState::PlayState()
{
}

PlayState::~PlayState()
{
}

SizeCharacter PlayState::RandomSizeCharacter()
{
	int num = Rand(1, 3);
	SizeCharacter size;
	switch (num)
	{
	case 1:
		{
			size = SizeCharacter::Big;
			break;
		}
		case 2:
		{
			size = SizeCharacter::Medium;
			break;
		}
		case 3:
		{
			size = SizeCharacter::Small;
			break;
		}
		default:
			break;
	}

	return size;
}

void PlayState::OnInit()
{
	m_score = 0;
	m_redBarValue = BAR_WIDTH;
	m_blueBarValue = BAR_WIDTH;

	m_isRedAvail = false;
	m_isBlueAvail = false;
	m_blueSize = RandomSizeCharacter();
	m_redSize = RandomSizeCharacter();


	// Init character
	for (size_t i = 0; i < NUM_CHARACTER; i++)
	{
		m_listBlueCharacter.push_back(new Character(false));
	}
	// Init character
	for (size_t i = 0; i < NUM_CHARACTER; i++)
	{
		m_listRedCharacter.push_back(new Character(true));
	}

	forceValueLineOne = 0;
	forceValueLineTwo = 0;
	forceValueLineThree = 0;

	listBlue.insert(std::pair<int, std::vector<Character*>>(1, std::vector<Character*>()));
	listBlue.insert(std::pair<int, std::vector<Character*>>(2, std::vector<Character*>()));
	listBlue.insert(std::pair<int, std::vector<Character*>>(3, std::vector<Character*>()));

	listRed.insert(std::pair<int, std::vector<Character*>>(1, std::vector<Character*>()));
	listRed.insert(std::pair<int, std::vector<Character*>>(2, std::vector<Character*>()));
	listRed.insert(std::pair<int, std::vector<Character*>>(3, std::vector<Character*>()));
}

void PlayState::OnUpdate(float deltaTime)
{
	if (m_redBarValue > 0)
	{
		m_redBarValue--;
	}
	else if (m_redBarValue == 0 && !m_isRedAvail)
	{
		m_isRedAvail = true;
	}

	if (m_blueBarValue > 0)
	{
		m_blueBarValue--;
	}
	else if (m_blueBarValue == 0 && !m_isBlueAvail)
	{
		m_isBlueAvail = true;
	}

	if (m_isRedAvail)
	{

		int idx = 0;
		while (m_listRedCharacter.at(idx)->IsEnable())
		{
			idx++;
		}
		m_redBarValue = BAR_WIDTH;
		m_isRedAvail = false;
		m_redSize = RandomSizeCharacter();
		m_listRedCharacter.at(idx)->SetSizeCharacter(m_redSize);
		int inLine = /*Rand(1, 3)*/1;
		m_listRedCharacter.at(idx)->SetLine(inLine);
		m_listRedCharacter.at(idx)->SetEnable(true);
		listRed.at(inLine).push_back(m_listRedCharacter.at(idx));
	}
	
	std::vector<Character*>::iterator blueCharacterPtr = m_listBlueCharacter.begin();
	for (; blueCharacterPtr != m_listBlueCharacter.end(); ++blueCharacterPtr)
	{
		if ((*blueCharacterPtr)->IsEnable())
		{
			if ((*blueCharacterPtr)->GetPosition().y <= DESTINATION_RATIO)
			{
				(*blueCharacterPtr)->SetEnable(false);

				listBlue[(*blueCharacterPtr)->GetLine()].erase(blueCharacterPtr);
			}

			(*blueCharacterPtr)->Update(deltaTime);
		}
	}

	std::vector<Character*>::iterator redCharacterPtr = m_listRedCharacter.begin();
	for (; redCharacterPtr != m_listRedCharacter.end(); ++redCharacterPtr)
	{
		if ((*redCharacterPtr)->IsEnable())
		{
			if ((*redCharacterPtr)->GetPosition().y >= SCREEN_HEIGHT - DESTINATION_RATIO)
			{
				(*redCharacterPtr)->SetEnable(false);

				listRed[(*redCharacterPtr)->GetLine()].erase(redCharacterPtr);
			}
			(*redCharacterPtr)->Update(deltaTime);
		}
	}

	CheckCollision(1);
	CheckCollision(2);
	CheckCollision(3);
}

void PlayState::OnRender(Graphics* graphics)
{
	graphics->DrawImage(ResourceManager::GetInstance()->GetImage(Background::MAP), 0, 0, 0);
	graphics->DrawImage(ResourceManager::GetInstance()->GetImage(Background::PlayerPut), 0, SCREEN_HEIGHT - 100, 0);
	graphics->DrawImage(ResourceManager::GetInstance()->GetImage(Background::AIPut), 0, 0, 0);

	graphics->DrawTextWithFont(ResourceManager::GetInstance()->GetFontById(1),
		0, 150, "Insance AI");

	graphics->SetColor(1.0f, 0.0f, 0.0f);	//RED
	graphics->DrawRect(SCREEN_WIDTH / 2.0f - BAR_WIDTH / 2.0f, SCREEN_HEIGHT - 150, BAR_WIDTH, BAR_HEIGHT);
	graphics->SetColor(1.0f, 0.0f, 0.0f);	//BLUE
	graphics->DrawRect(SCREEN_WIDTH / 2.0f - BAR_WIDTH / 2.0f, 100, BAR_WIDTH, BAR_HEIGHT);

	//Draw loading progress
	graphics->SetColor(1.0f, 1.0f, 1.0f);
	graphics->FillRect(SCREEN_WIDTH / 2.0f - BAR_WIDTH / 2.0f, 100, m_blueBarValue, BAR_HEIGHT);
	graphics->FillRect(SCREEN_WIDTH / 2.0f - BAR_WIDTH / 2.0f, SCREEN_HEIGHT - 150, m_redBarValue, BAR_HEIGHT);

	graphics->DrawImage(ResourceManager::GetInstance()->GetCharacterImage(m_blueSize, false), 0, 0, 0);
	graphics->DrawImage(ResourceManager::GetInstance()->GetCharacterImage(m_redSize, true), 0, 0, 0);

	std::vector<Character*>::iterator characterPtr = m_listBlueCharacter.begin();

	for (; characterPtr != m_listBlueCharacter.end(); ++characterPtr)
	{
		if ((*characterPtr)->IsEnable())
		{
			(*characterPtr)->Render(graphics);
		}
	}

	std::vector<Character*>::iterator redCharacterPtr = m_listRedCharacter.begin();

	for (; redCharacterPtr != m_listRedCharacter.end(); ++redCharacterPtr)
	{
		if ((*redCharacterPtr)->IsEnable())
		{
			(*redCharacterPtr)->Render(graphics);
		}
	}
}

void PlayState::TakeMousePoint(float x, float y, int state)
{
	if (state == 0)
	{
		int inLine = 0;

		if (x <= SCREEN_WIDTH / 3.f)
		{
			Logger::Debug("Touch::", "Touch  in range %d", 1);
			inLine = 1;
		}
		if (x > SCREEN_WIDTH / 3.f && x <= 2 * SCREEN_WIDTH / 3.f)
		{
			Logger::Debug("Touch::", "Touch  in range %d", 2);
			inLine = 2;
		}

		if (x > 2 * SCREEN_WIDTH / 3.f)
		{
			Logger::Debug("Touch::", "Touch  in range %d", 3);
			inLine = 3;
		}
		if (m_isBlueAvail)
		{
			m_blueBarValue = BAR_WIDTH;
			m_isBlueAvail = false;
			m_blueSize = RandomSizeCharacter();

			int idx = 0;
			while (m_listBlueCharacter.at(idx)->IsEnable())
			{
				idx++;
			}

			m_listBlueCharacter.at(idx)->SetSizeCharacter(m_blueSize);
			m_listBlueCharacter.at(idx)->SetLine(inLine);
			m_listBlueCharacter.at(idx)->SetEnable(true);

			listBlue.at(inLine).push_back(m_listBlueCharacter.at(idx));
		}
	}
}


void PlayState::CheckCollision(int inLine)
{
	if (listBlue[inLine].size() != 0 && listRed[inLine].size() != 0)
	{
		if (listRed[inLine].at(0)->IsBlocked() == true )
		{
			for (int idx = 1; idx < listBlue[inLine].size(); idx++)
			{
				if (listBlue[inLine].at(idx)->IsBlocked())
				{
					continue;
				}
				// Check collision
				if (listBlue[inLine].at(idx - 1)->GetPosition().y + listBlue[inLine].at(idx - 1)->GetSize() >= listBlue[inLine].at(idx)->GetPosition().y)
				{
					listBlue[inLine].at(idx)->Blocked(true);
				}
			}
			for (int idx = 1; idx < listRed[inLine].size(); idx++)
			{
				if (listRed[inLine].at(idx)->IsBlocked())
				{
					continue;
				}
				// Check collision
				if (listRed[inLine].at(idx - 1)->GetPosition().y <= listRed[inLine].at(idx)->GetPosition().y + listRed[inLine].at(idx)->GetSize())
				{
					listRed[inLine].at(idx)->Blocked(true);
				}
			}
		}
		else
		{
			// Check collision
			if (listRed[inLine].at(0)->GetPosition().y + listRed[inLine].at(0)->GetSize() >= listBlue[inLine].at(0)->GetPosition().y)
			{
				listRed[inLine].at(0)->Blocked(true);
				listBlue[inLine].at(0)->Blocked(true);
			}
		}
	}
}

std::vector<Character*>	PlayState::GetCharacterInLine(int numLine, bool isAI)
{
	std::vector<Character*> temp;
	if (isAI)
	{
		std::vector<Character*>::iterator blueCharacterPtr;
		for (; blueCharacterPtr != m_listBlueCharacter.end(); ++blueCharacterPtr)
		{
			if ((*blueCharacterPtr)->IsEnable() && (*blueCharacterPtr)->GetLine() == numLine)
			{
				temp.push_back((*blueCharacterPtr));
			}
		}
	}
	else
	{
		std::vector<Character*>::iterator redCharacterPtr;
		for (; redCharacterPtr != m_listRedCharacter.end(); ++redCharacterPtr)
		{
			if ((*redCharacterPtr)->IsEnable() && (*redCharacterPtr)->GetLine() == numLine)
			{
				temp.push_back((*redCharacterPtr));
			}
		}
	}
	return temp;
}


void PlayState::OnExit()
{

}