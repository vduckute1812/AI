#include "Character.h"
#include "Define.h"

Character::Character(bool isAI)
{
	m_characterAnim = nullptr;
	m_isAI = isAI;
	m_inLine = 0;
	m_isEnable = false;
	m_isBlocked = false;
}

Character::Character(SizeCharacter size, int num, bool isAI)
{
	m_characterAnim = ResourceManager::GetInstance()->GetAnimation(size, isAI);
	m_characterAnim->PlayAnimation();
	m_isAI = false;
	m_inLine = num;
	m_isEnable = false;
	m_size = size;
	m_isAI = isAI;
	m_currentPosition = Vector2(num * SCREEN_WIDTH / 3.f, SCREEN_HEIGHT);
}

Character::~Character()
{
}

void Character::Update(float delta)
{
	int direction = m_isAI ? 1 : -1;
	if (m_isBlocked)
		direction = 0;
	m_currentPosition.y += delta * direction * CHARACTER_SPEED;
}

void Character::Render(Graphics* graphics)
{
	//m_characterAnim->PlayAnimation();
	graphics->DrawAnimation(m_characterAnim, m_currentPosition.x, m_currentPosition.y);
	graphics->DrawRect(m_currentPosition.x, m_currentPosition.y, m_characterAnim->GetWidth(), m_characterAnim->GetHeight());
}

bool Character::IsAI() const
{
	return m_isAI;
}

void Character::SetLine(int num)
{
	m_inLine = num;
	m_currentPosition.x = (m_inLine - 1) * SCREEN_WIDTH / 3.f + PADDING_CHARACTER;

	m_currentPosition.x -= GetSize() / 2.f;
	m_currentPosition.y = (m_isAI ? 0 : SCREEN_HEIGHT);
}

int Character::GetLine() const
{
	return m_inLine;
}

Vector2 Character::GetPosition() const
{
	return m_currentPosition;
}

void Character::SetEnable(bool isEnable)
{
	m_isEnable = isEnable;
}

bool Character::IsEnable()
{
	return m_isEnable;
}

bool Character::IsBlocked()
{
	return m_isBlocked;
}

void Character::Blocked(bool blocked)
{
	m_isBlocked = blocked;
}

void Character::SetSizeCharacter(SizeCharacter size)
{
	m_size = size;
	m_characterAnim = ResourceManager::GetInstance()->GetAnimation(m_size, m_isAI);
	m_characterAnim->PlayAnimation();
}

int Character::GetSize() const
{
	int size = 0;
	switch (m_size)
	{
	case Big:
	{
		size = BIG_CHARACTER_WIDTH;
		break;
	}
	case Medium:
	{
		size = MEDIUM_CHARACTER_WIDTH;
		break;
	}
	case Small:
	{
		size = SMALL_CHARACTER_WIDTH;
		break;
	}
	default:
		break;
	}
	
	return size;
}
