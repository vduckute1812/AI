#include <string>
#include <memory>
#include "ResourceManager.h"

const int NUM_FRAME_SWITCH_IMAGE = 10;
const int NUM_IMAGE = 7;



void ResourceManager::Init()
{
	// Background
	images.insert(std::pair<Background, Image*>(Background::MAP, new Image("../Resources/Data/map.png")));
	images.insert(std::pair<Background, Image*>(Background::AIPut, new Image("../Resources/Data/AIPut.png")));
	images.insert(std::pair<Background, Image*>(Background::PlayerPut, new Image("../Resources/Data/PlayerPut.png")));
	images.insert(std::pair<Background, Image*>(Background::Powerup, new Image("../Resources/Data/Powerup.png")));

	images.insert(std::pair<Background, Image*>(Background::BigAIBack, new Image("../Resources/Data/AI/BIG/player_full_1.png")));
	images.insert(std::pair<Background, Image*>(Background::MediumAIBack, new Image("../Resources/Data/AI/MEDIUM/player_full_1.png")));
	images.insert(std::pair<Background, Image*>(Background::SmallAIBack, new Image("../Resources/Data/AI/SMALL/player_full_1.png")));

	images.insert(std::pair<Background, Image*>(Background::BigPlayerBack, new Image("../Resources/Data/Player/BIG/player_full_1.png")));
	images.insert(std::pair<Background, Image*>(Background::MediumPlayerBack, new Image("../Resources/Data/Player/MEDIUM/player_full_1.png")));
	images.insert(std::pair<Background, Image*>(Background::SmallPlayerBack, new Image("../Resources/Data/Player/SMALL/player_full_1.png")));


	const char* prevButton = "../Resources/PlayBttNormal.png";
	const char* pressButton = "../Resources/PlayBttPressing.png";
	button = new UIButton(prevButton, pressButton);

	// Font
	fonts.insert(std::pair<int, Font*>(0, new Font("../Resources/Data/Fonts/font.fnt")));
	fonts.insert(std::pair<int, Font*>(1, new Font("../Resources/Data/Fonts/fontPolygon.fnt")));

	// Animation
	LoadAnimation(SizeCharacter::Big, true);
	LoadAnimation(SizeCharacter::Big, false);
	LoadAnimation(SizeCharacter::Medium, true);
	LoadAnimation(SizeCharacter::Medium, false);
	LoadAnimation(SizeCharacter::Small, true);
	LoadAnimation(SizeCharacter::Small, false);
}

void ResourceManager::Destroy()
{

}

Image* ResourceManager::GetImage(Background id)
{
	return images.find(id)->second;
}

Image* ResourceManager::GetCharacterImage(SizeCharacter size, bool isAI)
{
	int idx = 4;
	
	if (isAI)
	{
		idx += 3;
	}

	switch (size)
	{
	case Big:
	{
		idx += 0;
		break;
	}
	case Medium:
	{
		idx += 1;
		break;
	}
	case Small:
	{
		idx += 2;
		break;
	}
	default:
		break;
	}

	return GetImage(Background(idx));
}

void ResourceManager::LoadAnimation(SizeCharacter size, bool isAI)
{
	int idx = 0;
	if (isAI)
	{
		idx += 3;
	}

	char* mode = isAI ? "AI" : "PLAYER";
	char* sizeCharacter = "";

	switch (size)
	{
	case Big:
	{
		idx += 0;
		sizeCharacter = "BIG";
		break;
	}
	case Medium:
	{
		idx += 1;
		sizeCharacter = "MEDIUM";
		break;
	}
	case Small:
	{
		idx += 2;
		sizeCharacter = "SMALL";
		break;
	}
	default:
		break;
	}

	// Add AI bot animation
	for (int i = 1; i <= NUM_IMAGE; i++)
	{
		char path[256];
		sprintf(path, "../Resources/Data/%s/%s/player_full_%d.png", mode, sizeCharacter, i);
		listImages.push_back(new Image(path));
	}
	botAnims.insert(std::pair<int, Animation*>(idx, new Animation(listImages, NUM_FRAME_SWITCH_IMAGE)));
	listImages.clear();
}


Font* ResourceManager::GetFontById(int id)
{
	return fonts.find(id)->second;
}

Animation* ResourceManager::GetAnimation(SizeCharacter size, bool isAI)
{
	int idx = 0;
	if (isAI)
	{
		idx += 3;
	}
		
	switch (size)
	{
	case Big:
	{
		idx += 0;
		break;
	}
	case Medium:
	{
		idx += 1;
		break;
	}
	case Small:
	{
		idx += 2;
		break;
	}
	default:
		break;
	}


	return botAnims.find(idx)->second;
}
