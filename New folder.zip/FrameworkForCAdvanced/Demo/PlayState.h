#pragma once
#include <vector>
#include <memory>
#include "State.h"
#include "Character.h"

class PlayState: public State
{
public:
	virtual void TakeMousePoint(float x, float y, int state);
	virtual void OnInit();
	virtual void OnUpdate(float deltaTime);
	virtual void OnRender(Graphics* graphics);
	virtual void OnExit();

	void	CheckCollision(int inLine);
	std::vector<Character*>	GetCharacterInLine(int numLine, bool isAI);

	PlayState();
	~PlayState();

	SizeCharacter RandomSizeCharacter();

private:
	int			m_score;
	int			m_redBarValue;
	int			m_blueBarValue;

	std::vector<Character*>	m_listRedCharacter;
	std::vector<Character*>	m_listBlueCharacter;

	bool		m_isRedAvail;
	bool		m_isBlueAvail;

	SizeCharacter	m_blueSize;
	SizeCharacter	m_redSize;

	std::map<int, std::vector<Character*>> listBlue;
	std::map<int, std::vector<Character*>> listRed;

	int				forceValueLineOne;
	int				forceValueLineTwo;
	int				forceValueLineThree;
};

