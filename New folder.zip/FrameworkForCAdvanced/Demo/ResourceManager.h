#pragma once
#include <map>
#include "GameEngine.h"
#include "Singleton.h"


enum Background
{
	MAP,
	AIPut,
	PlayerPut,
	Powerup,
	BigAIBack,
	MediumAIBack,
	SmallAIBack,
	BigPlayerBack,
	MediumPlayerBack,
	SmallPlayerBack
};

enum SizeCharacter
{
	Big,
	Medium,
	Small
};

//typedef std::map<SizeCharacter, Animation*> BotAnimation;

class ResourceManager: public Singleton<ResourceManager>
{
public:
	virtual void Init() override;
	virtual void Destroy() override;
	Image* GetImage(Background id);
	Image* GetCharacterImage(SizeCharacter size, bool isAI);
	void		LoadAnimation(SizeCharacter size, bool isAI);
	Animation*	GetAnimation(SizeCharacter size, bool isAI);
	Font*		GetFontById(int id);

private:

	bool		m_isResource;

	UIButton*				button;
	std::list<Image*>		listImages;
	std::map<Background, Image*>		images;
	std::map<int, Font*>		fonts;
	std::map<int, Animation*>	botAnims;

};

