#pragma once
#include <random>


const int SCREEN_WIDTH = 480;
const int SCREEN_HEIGHT = 800;
const float RADIUS = 60.0f;
const float BAR_WIDTH = 100.0f;
const float BAR_HEIGHT = 20.0f;

const float DESTINATION_RATIO = 100;

//const 

const int BIG_CHARACTER_WIDTH = 76;
const int MEDIUM_CHARACTER_WIDTH = 60;
const int SMALL_CHARACTER_WIDTH = 40;

const int LOADING_SPEED = 80;
const int CHARACTER_SPEED = 80;

const int NUM_CHARACTER = 30;

const int BIG_AI_BACKGROUND = 4;
const int MEDIUM_AI_BACKGROUND = 5;
const int SMALL_AI_BACKGROUND = 6;

const int BIG_PLAYER_BACKGROUND = 7;
const int MEDIUM_PLAYER_BACKGROUND = 8;
const int SMALL_PLAYER_BACKGROUND = 9;

const int PADDING_CHARACTER = 80;

static int Rand(int min, int max)
{
	std::random_device rd;  //Will be used to obtain a seed for the random number engine
	std::mt19937 gen(rd()); //Standard mersenne_twister_engine seeded with rd()
	std::uniform_int_distribution<> dis(min, max);

	return dis(gen);
}