#pragma once
#include "GameEngine.h"
#include "ResourceManager.h"

class Character
{
public:
	Character(bool isAI);
	Character(SizeCharacter size, int num, bool isAI);
	~Character();

	void Update(float delta);
	void Render(Graphics* graphics);

	bool IsAI() const;

	void SetLine(int num);
	int	 GetLine() const;

	Vector2 GetPosition() const;

	void	SetEnable(bool);
	bool	IsEnable();

	bool	IsBlocked();
	void	Blocked(bool blocked);

	void	SetSizeCharacter(SizeCharacter size);
	int		GetSize() const;

private:
	SizeCharacter m_size;
	bool		m_isAI;
	int			m_inLine;
	bool		m_isBlocked;
	bool		m_isEnable;
	Vector2		m_currentPosition;
	Animation*	m_characterAnim;
};

