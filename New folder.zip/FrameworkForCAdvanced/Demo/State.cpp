#include "State.h"


State::State()
{
}


State::~State()
{
}

void State::TakeMousePoint(float x, float y, int mouseState)
{	
}
